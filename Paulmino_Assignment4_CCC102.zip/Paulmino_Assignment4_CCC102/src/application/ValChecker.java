package application;

import java.util.Scanner;

public class ValChecker {
	
	
	
private int validBase;
	
	
	//Constructs a Checker object.
	public ValChecker()
	{
		this.validBase = validBase;
	}
	

	

    /**
     * Checks if the given base is valid for a number system.
     *
     * @param base The base to be checked.
     * @throws ArithmeticException if the base is not valid (not 2, 8, 10, or 16).
     */
	public void CheckBase(int base) throws ArithmeticException
	{
		if(base != 2 && base != 8 && base != 10 && base !=16)
		{
			throw new ArithmeticException("Invalid base for Number System: " + base);
		}
	}
	
	
	
	
	
	/**
     * Checks if the given string is a valid binary number.
     *
     * @param str The string to be checked.
     * @throws InvalidInputException if the string is not a valid binary number.
     */
	public void CheckBinary(String str) throws InvalidInputException1 {
	    for (int i = 0; i < str.length(); i++) {
	        char c = str.charAt(i);
	        if (c != '0' && c != '1') {
	            throw new InvalidInputException1("Invalid binary number: " + str);
	        }
	    }
	}
	
	
	
	
	/**
     * Checks if the given string is a valid octal number.
     *
     * @param str The string to be checked.
     * @throws InvalidInputException if the string is not a valid octal number.
     */
	public void CheckOctal(String str) throws InvalidInputException1
	{
		for(int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			if(c < '0' || c > '7') {
				throw new InvalidInputException1("Invalid Octadecimal number: " + str);
			}
		}
	}
	
	
	
	 /**
     * Checks if the given string is a valid decimal number.
     *
     * @param input The string to be checked.
     * @throws InvalidInputException if the string is not a valid decimal number.
     */
	public void CheckDecimal(String input) throws InvalidInputException1 {
	    for (int i = 0; i < input.length(); i++) {
	        char c = input.charAt(i);
	        if (!Character.isDigit(c)) {
	            throw new InvalidInputException1("Invalid decimal: " + input);
	        }
	    }
	}
	
	
	
	/**
     * Checks if the given string is a valid hexadecimal number.
     *
     * @param input The string to be checked.
     * @throws InvalidInputException if the string is not a valid hexadecimal number.
     */
	public void CheckHexadecimal(String input) throws InvalidInputException1 {
	    for (int i = 0; i < input.length(); i++) {
	        char c = input.charAt(i);
	        if (!validHexa(c)) {
	            throw new InvalidInputException1("Invalid hexadecimal digit: " + c);
	        }
	    }
	}

	
	
	/**
     * Checks if the given character is a valid hexadecimal digit.
     *
     * @param c The character to be checked.
     * @return {@code true} if the character is a valid hexadecimal digit, {@code false} otherwise.
     */
	public boolean validHexa(char c) {
	    return (c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f');
	}
	
	
	
	
	

    /**
     * Reads an integer input from the provided scanner and returns the value.
     *
     * @param scanner The scanner to read the input from.
     * @return The integer value read from the scanner.
     * @throws InvalidInputException if the input is not a valid integer.
     */
	 public int readIntegerInput1(Scanner scanner) throws InvalidInputException1 {
	        if (!scanner.hasNextInt()) {
	            String invalidInput = scanner.next();
	            throw new InvalidInputException1("Invalid input: Please enter an integer. Received: " + invalidInput);
	        }
	        return scanner.nextInt();
	    }
}
