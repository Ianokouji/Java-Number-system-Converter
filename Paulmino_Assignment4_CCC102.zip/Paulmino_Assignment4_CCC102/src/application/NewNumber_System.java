package application;

public class NewNumber_System {
	
	/**
	 * The Number_System class represents a number system 
	 * and provides methods to convert values between different number systems.
	 */
	
	
		
		private String MUval;
		private int  base;
		private String Value = "0123456789ABCDEF";
		
		
		
		
	    /**
	     * Constructs a Number_System object with the specified base.
	     *
	     * @param base The base of the number system.
	     */
		public NewNumber_System(int base)
		{
		
			this.base = base;
		
		}
		
			
		
		
		 /**
	     * Converts the given value from the current number system to the specified base.
	     *
	     * @param Uval  The value to be converted.
	     * @param base  The base of the target number system.
	     * @return The converted value in the target number system.
	     */
		public String convertTo(String Uval, int base) {
			
			int decimal = 0;
			String finish_convert = "";
			
			for(int i = 0; i<Uval.length(); i++)
			{
				decimal += getVal(Uval.charAt(i))*(int)Math.pow(this.base,Uval.length()-1-i);
			}
			
			while(decimal !=0) {
				char remain = getChar(decimal % base);
				decimal = decimal/ base;
				finish_convert = remain + finish_convert;
				
			}
			SetUval(Uval);
			SetBase(base);
			return finish_convert;
			
		}
		
		
		
		// Accessors and Mutators so I could access and print the values insides convertTo method
		public void SetBase(int base)
		{
			this.base = base;
		}
		

		public void SetUval(String Uval)
		{
			MUval = Uval;
		}
		
		public String GetUval(){
			return MUval;
		}
		public int GetUBase()
		{
			return base;
		}
		


	    /**
	     * Prints the base of the number system and the value to be converted.
	     */
	    public void ToString() {
	    	System.out.println( "#" + GetUBase() + " [" + GetUval() + "]");
	        
	    }
		
	    
	    
	    
	    
	    
	    

	    /**
	     * Retrieves the numeric value of the specified character.
	     *
	     * @param find The character to find the numeric value of.
	     * @return The numeric value of the character.
	     */
	    public int getVal(char find) {
	        int val;
	        if (Character.isDigit(find)) {
	            val = Character.getNumericValue(find);
	        } else {
	            val = Character.toUpperCase(find) - 'A' + 10;
	        }
	        return val;
	    }
	    
	    
	    

	    /**
	     * Retrieves the character representation of the specified numeric value.
	     *
	     * @param find The numeric value to find the character representation of.
	     * @return The character representation of the numeric value.
	     */
		public char getChar(int find) {
		    return Value.charAt(find); 
		} 

		

			
		

		
}
