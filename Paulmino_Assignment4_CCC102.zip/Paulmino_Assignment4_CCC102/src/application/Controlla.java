package application;



import java.net.URL;
import java.util.ResourceBundle;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.shape.Circle;
import javafx.scene.shape.CubicCurve;
import javafx.scene.shape.Polygon;
//gpt imports
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.shape.Circle;



/**
 * Controller class for the JavaFX application.
 */
public class Controlla implements Initializable {

	
	// FXML fields
	
	@FXML 
	private Circle Mycircle;
	private double x,y;
	
	

	@FXML public void Decimal() {
		System.out.println("Dec");
		Mycircle.setCenterY(y+=10);
	}
	//@FXML public void HexaDecimal(ActionEvent event) {}
	@FXML public void HexaDecimal() {
		System.out.println("Hexa");
		Mycircle.setCenterY(y-=10);
		
	}
	@FXML public void OctaDecimal() {
		System.out.println("Octa");
		Mycircle.setCenterX(x+=10);
	}
	@FXML public void binary() {
		System.out.println("Bina");
		Mycircle.setCenterX(x-=10);
		
	}
	
	
	@FXML
	private Slider Slider_base;
	@FXML
	private Slider Slider_Newbase;
	@FXML
	private Label testlabel;
	@FXML
	private Label testlabel2;
	@FXML
	private Label convertedval;
	@FXML
	private TextField valtextfield;
	
	
	//design triangles that detect error
	@FXML
    private Polygon tri1;
	@FXML
    private Polygon tri2;
	@FXML
    private Polygon tri3;
	@FXML
    private Polygon tri4;
	@FXML
    private Polygon tri5;
	@FXML
    private Polygon tri6;
	
	// Other fields
	int testval;
	int testval2;
	private int base1;
	private int base2;
	
	
	/**
	 * Called to initialize the controller after its root element has been completely processed.
	 * 
	*/
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		testval = (int)Slider_base.getValue();
		updateLabel(testval);
		//testlabel.setText(Integer.toString(testval));
		
		
		testval2 = (int)Slider_Newbase.getValue();
		updateLabel2(testval2);
		//testlabel2.setText(Integer.toString(testval));
		
		Slider_base.valueProperty().addListener(new ChangeListener<Number>()
		{

			@Override
			public void changed(ObservableValue<? extends Number> arg0, Number arg1, Number arg2) {
				
				testval = (int)Slider_base.getValue();
				//testlabel.setText(Integer.toString(testval));
				updateLabel(testval);
			}
			
			
		
		
		});
		
		Slider_Newbase.valueProperty().addListener(new ChangeListener<Number>()
		{

			@Override
			public void changed(ObservableValue<? extends Number> arg1, Number arg2, Number arg3) {
				
				testval2 = (int)Slider_Newbase.getValue();
				//testlabel2.setText(Integer.toString(testval2));
				updateLabel2(testval2);
			}
			
			
		
		
		});
		
			
	}
	
	
	
	
	//Make getter and setter to access the updating values
		public void setBase1(int base1)
		{
			this.base1 = base1;
		}
		
		public int getBase1()
		{
			return base1;
		}
		
		public void setBase2(int base2)
		{
			this.base2 = base2;
		}
		
		public int getBase2()
		{
			return base2;
		}
	

	
		
		
		
		
		
		
		
		
	//For label 1 that gets the updated values of Slider 1	
	private void updateLabel(int value) 
	{
	    if (value >= 0 && value <= 25)
	    	{
	        	testlabel.setText("From Binary");
	        	int valuebase = 2;
	        	setBase1(valuebase);
	        	System.out.println(valuebase);
	        	
	        
	    	} 
	    
	    else if(value >= 26 && value <= 50)
	    	{
	    		testlabel.setText("From OctaDecimal");
	    		int valuebase = 8;
	    		setBase1(valuebase);
	    		System.out.println(valuebase);
	    	}
	    else if(value >= 51 && value <= 75)
    	{
    		testlabel.setText("From Decimal");
    		int valuebase = 10;
    		setBase1(valuebase);
    		System.out.println(valuebase);
    	}
	    else if(value >= 76 && value <= 100)
    	{
    		testlabel.setText("From HexaDecimal");
    		int valuebase = 16;
    		setBase1(valuebase);
    		System.out.println(valuebase);
    	}
	    
	    
	    
	    
	    else 
	    	{
	        	testlabel.setText(Integer.toString(value));
	    	}
	
	}
	
	
	
	
	
	//For label 2 that gets the updated values of Slider 2	
	private void updateLabel2(int value) 
	{
	    if (value >= 0 && value <= 25)
	    	{
	        	testlabel2.setText("To Binary");
	        	int valuebase2 = 2;
	        	setBase2(valuebase2);
	        	System.out.println(valuebase2);
	        	
	        
	    	} 
	    
	    else if(value >= 26 && value <= 50)
	    	{
	    		testlabel2.setText("To OctaDecimal");
	    		int valuebase2 = 8;
	    		setBase2(valuebase2);
	    		System.out.println(valuebase2);
	    	}
	    else if(value >= 51 && value <= 75)
    	{
    		testlabel2.setText("To Decimal");
    		int valuebase2 = 10;
    		setBase2(valuebase2);
    		System.out.println(valuebase2);
    	}
	    else if(value >= 76 && value <= 100)
    	{
    		testlabel2.setText("To HexaDecimal");
    		int valuebase2 = 16;
    		setBase2(valuebase2);
    		System.out.println(valuebase2);
    	}
	    
	    
	    
	    
	    else 
	    	{
	        	testlabel2.setText(Integer.toString(value));
	    	}
	
	}
	
	

	//Executes code when convert button is pressed 
	@FXML public void convert()
	{
		ValChecker verify = new ValChecker();
		String Value = valtextfield.getText();
		
		//Code that handles Binary
		if(getBase1() == 2)
		{	
			
			NewNumber_System Number = new NewNumber_System(getBase1());
			try {
			verify.CheckBinary(Value);
			
			}
			
			catch(InvalidInputException1 b){
				convertedval.setText("Invalid Binary ");
				b.printStackTrace();
				//design when error is made
				Mycircle.getStyleClass().add("error");
				tri1.getStyleClass().add("error");
				tri2.getStyleClass().add("error");
				tri3.getStyleClass().add("error");
				tri4.getStyleClass().add("error");
				tri5.getStyleClass().add("error");
				tri6.getStyleClass().add("error");
				return;
			}
			
			//design when there is a corrected error
			Mycircle.getStyleClass().remove("error");
			tri1.getStyleClass().remove("error");
			tri2.getStyleClass().remove("error");
			tri3.getStyleClass().remove("error");
			tri4.getStyleClass().remove("error");
			tri5.getStyleClass().remove("error");
			tri6.getStyleClass().remove("error");
			convertedval.setText( Number.convertTo(Value, getBase2()));
			return;
			
		}
		
		//Code that handles Octadecimal
		else if(getBase1() == 8)
		{	
			NewNumber_System Number = new NewNumber_System(getBase1());
			try {
			verify.CheckOctal(Value);
			
			}
			
			catch(InvalidInputException1 o){
				convertedval.setText("Invalid OctaDecimal ");
				o.printStackTrace();
				//design when error is made
				Mycircle.getStyleClass().add("error");
				tri1.getStyleClass().add("error");
				tri2.getStyleClass().add("error");
				tri3.getStyleClass().add("error");
				tri4.getStyleClass().add("error");
				tri5.getStyleClass().add("error");
				tri6.getStyleClass().add("error");
				return;
			}
			
			Mycircle.getStyleClass().remove("error");
			tri1.getStyleClass().remove("error");
			tri2.getStyleClass().remove("error");
			tri3.getStyleClass().remove("error");
			tri4.getStyleClass().remove("error");
			tri5.getStyleClass().remove("error");
			tri6.getStyleClass().remove("error");
			convertedval.setText( Number.convertTo(Value, getBase2()));
			return;
			
		}
		
		
		//Code that handles Decimal
		else if(getBase1() == 10)
		{	
			NewNumber_System Number = new NewNumber_System(getBase1());
			try {
			verify.CheckDecimal(Value);
			
			}
			
			catch(InvalidInputException1 d){
				convertedval.setText("Invalid Decimal ");
				d.printStackTrace();
				Mycircle.getStyleClass().add("error");
				tri1.getStyleClass().add("error");
				tri2.getStyleClass().add("error");
				tri3.getStyleClass().add("error");
				tri4.getStyleClass().add("error");
				tri5.getStyleClass().add("error");
				tri6.getStyleClass().add("error");
				return;
			}
			
			Mycircle.getStyleClass().remove("error");
			tri1.getStyleClass().remove("error");
			tri2.getStyleClass().remove("error");
			tri3.getStyleClass().remove("error");
			tri4.getStyleClass().remove("error");
			tri5.getStyleClass().remove("error");
			tri6.getStyleClass().remove("error");
			convertedval.setText( Number.convertTo(Value, getBase2()));
			return;
			
		}
		
		//Code that handles HexaDecimal
				else if(getBase1() == 16)
				{	
					NewNumber_System Number = new NewNumber_System(getBase1());
					try {
					verify.CheckHexadecimal(Value);
					
					}
					
					catch(InvalidInputException1 b){
						convertedval.setText("Invalid HexaDecimal ");
						b.printStackTrace();
						Mycircle.getStyleClass().add("error");
						tri1.getStyleClass().add("error");
						tri2.getStyleClass().add("error");
						tri3.getStyleClass().add("error");
						tri4.getStyleClass().add("error");
						tri5.getStyleClass().add("error");
						tri6.getStyleClass().add("error");
						return;
					}
					
					Mycircle.getStyleClass().remove("error");
				    tri1.getStyleClass().remove("error");
				    tri2.getStyleClass().remove("error");
					tri3.getStyleClass().remove("error");
					tri4.getStyleClass().remove("error");
					tri5.getStyleClass().remove("error");
					tri6.getStyleClass().remove("error");
					convertedval.setText( Number.convertTo(Value, getBase2()));
					return;
					
				}
		
		
		
		else
		{
			convertedval.setText("DOES NOT EXIST");
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}