package application;

public class InvalidInputException1 extends Exception{

	
	/**
     * Constructs an InvalidInputException with the specified error message.
     *
     * @param message The error message associated with the exception.
     */
	public InvalidInputException1(String message) {
        super(message);
    }
}
