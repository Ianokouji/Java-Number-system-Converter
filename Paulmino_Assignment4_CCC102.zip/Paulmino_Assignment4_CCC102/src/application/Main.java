
/*
 * CCC102 ASSIGNMENT 4 
 * GUI FOR NUMBER SYSTEM CONVERTER
 * 
 * 
 * 
 * 
 * AUTHOR: IAN GABRIEL D. PAULMINO
 * 
 * 
 */
package application;
	
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.image.*;
import javafx.scene.Parent;
import javafx.fxml.FXMLLoader;

/**
 * The Main class is the entry point for the JavaFX application.
 */
public class Main extends Application {
	
	 /**
     * The start method is called when the application is launched.
     *
     * @param primaryStage the primary stage for the application
     */
	@Override
	public void start(Stage primaryStage) {
		try {
			
			//Parent root = FXMLLoader.load(getClass().getResource("Mainfx.fxml"));
			Parent root = FXMLLoader.load(getClass().getResource("Mainfx.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			String css = this.getClass().getResource("application.css").toExternalForm();
			scene.getStylesheets().add(css);
			
			Image icon = new Image("Logo.jpg");      //creates image instance for icon
			primaryStage.getIcons().add(icon);       //adds the image to the stage
			primaryStage.setTitle("Number System Converter by Paulmino");
			primaryStage.setResizable(false);
			
			
			
			
			
			
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
     * The main method is the entry point of the Java application.
     *
     * @param args the command line arguments
     */
	public static void main(String[] args) {
		launch(args);
	}
}
